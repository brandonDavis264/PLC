package plc.project.evaluator;

public final class EvaluateException extends Exception {

    public EvaluateException(String message) {
        super(message);
    }

}
