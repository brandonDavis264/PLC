package plc.project.lexer;

public final class LexException extends Exception {

    public LexException(String message) {
        super(message);
    }

}
