package plc.project;

import com.google.common.base.Preconditions;
import plc.project.lexer.LexException;
import plc.project.lexer.Lexer;

import java.util.Scanner;

public final class Main {

    public static void main(String[] args) {
        /**
         * Design By Contract: (Error Handling)
         *         - Preconditions.checkArgument(args.length == 1);
         *         - throws exception -> Look at LexException Class
         *         - try{}catch(exception e)
         *              - Least useful way to handle the exception
         *              - Meaningful Messages
         */

        var scanner = new Scanner(System.in);
        while (true) {
            var input = scanner.nextLine();
            try {
                var tokens = new Lexer(input).lex();
                System.out.println(tokens);
            } catch (LexException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
