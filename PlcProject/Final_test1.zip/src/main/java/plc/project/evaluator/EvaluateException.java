package plc.project.evaluator;

/**
 * IMPORTANT: DO NOT CHANGE! This file is part of our project's API and should
 * not be modified by your solution.
 */
public final class EvaluateException extends Exception {

    public EvaluateException(String message) {
        super(message);
    }

}
